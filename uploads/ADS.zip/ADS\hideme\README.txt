This folder is hidden in cache.log
 - DruUg